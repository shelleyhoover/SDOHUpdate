#----------------
#Descriptive Statistics for Clusters
#COUNTY
#----------------

# Libraries 
library(dplyr)
library(ggplot2)
library(gridExtra)
library(tidyr)
library(reshape2)
library(grid)


sdoh_2013 <- read.csv("County_2013PCAKMeans.csv")
sdoh_2018 <- read.csv("County_2018PCAKMeans.csv")
sdoh_2023 <- read.csv("County_2023PCAKMeans.csv")



# Define the list of demographic characteristics
demographic_vars <- c("NOHSDP", "LIMENG", "SNGPNT", "DISABL", "UNINSR", "UNEMP", "CROWD", "RENTER", "RENTBURD", "NOVEH", "MINRTY", "AGE65", "AGE19", "PCI", "POVER")  

#--------------------------------------------------
# Calculate descriptive statistics for each cluster
#--------------------------------------------------

#2013

descriptive_stats2013 <- sdoh_2013 %>%
  group_by(CL) %>%
  summarise(across(all_of(demographic_vars), 
                   list(mean = ~mean(. , na.rm = TRUE),
                        sd = ~sd(. , na.rm = TRUE),
                        min = ~min(. , na.rm = TRUE),
                        max = ~max(. , na.rm = TRUE),
                        median = ~median(. , na.rm = TRUE)),
                   .names = "{.col}_{.fn}"))

#2018
descriptive_stats2018 <- sdoh_2018 %>%
  group_by(CL) %>%
  summarise(across(all_of(demographic_vars), 
                   list(mean = ~mean(. , na.rm = TRUE),
                        sd = ~sd(. , na.rm = TRUE),
                        min = ~min(. , na.rm = TRUE),
                        max = ~max(. , na.rm = TRUE),
                        median = ~median(. , na.rm = TRUE)),
                   .names = "{.col}_{.fn}"))


#2023
descriptive_stats2023 <- sdoh_2023 %>%
  group_by(CL) %>%
  summarise(across(all_of(demographic_vars), 
                   list(mean = ~mean(. , na.rm = TRUE),
                        sd = ~sd(. , na.rm = TRUE),
                        min = ~min(. , na.rm = TRUE),
                        max = ~max(. , na.rm = TRUE),
                        median = ~median(. , na.rm = TRUE)),
                   .names = "{.col}_{.fn}"))


# Save results to a CSV file
write.csv(descriptive_stats2013, "descriptive_stats2013_county.csv", row.names = FALSE)
write.csv(descriptive_stats2018, "descriptive_stats2018_county.csv", row.names = FALSE)
write.csv(descriptive_stats2023, "descriptive_stats2023_county.csv", row.names = FALSE)


#-------------
# BOX PLOTS 
#------------

# Create a list to store plots
plot_list2013 <- list()
plot_list2018 <- list()
plot_list2023 <- list()
#2013

# Generate boxplots for each demographic variable
for (var in demographic_vars) {
  p2013 <- ggplot(sdoh_2013, aes(x = as.factor(CL), y = .data[[var]], fill = as.factor(CL))) +
    geom_boxplot(outlier.shape = NA, alpha = 0.7) +  # Adjust alpha for visibility
    labs(title = var, x = "2013Cluster", y = var) +
    theme_minimal() +
    theme(legend.position = "none")  # Hide legends for cleaner display
  plot_list2013[[var]] <- p2013
}

# Arrange plots in a 5x3 grid
grid.arrange(grobs = plot_list2013, ncol = 3, nrow = 5)


#--------
#heat map
#--------

# Calculate standardized means by cluster
cluster_means13 <- sdoh_2013 %>%
  group_by(CL) %>%
  summarise(across(all_of(demographic_vars), mean, na.rm = TRUE), .groups = 'drop') %>%
  mutate(across(all_of(demographic_vars), ~ as.numeric(scale(.x)))) %>%  # Standardize AFTER grouping
  pivot_longer(cols = all_of(demographic_vars), 
               names_to = "indicator", 
               values_to = "mean_zscore")


# Check the data structure
print(head(cluster_means13))
print(colnames(cluster_means13))

# Create heatmap
ggplot(cluster_means13, aes(x = indicator, y = as.factor(CL), fill = mean_zscore)) +
  geom_tile(color = "white") +
  scale_fill_gradient2(low = "blue", mid = "white", high = "red", 
                       midpoint = 0, name = "Z-score") +
  labs(title = "Cluster Heatmap 2013",
       subtitle = "Red = Above Average, Blue = Below Average",
       x = "Indicator", y = "Cluster") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


#---

# Faceted version for clearer individual cluster profiles
ggplot(cluster_means13, aes(x = indicator, y = mean_zscore, fill = mean_zscore > 0)) +
  geom_col(width = 0.7) +
  geom_hline(yintercept = 0, color = "black", size = 0.8) +
  scale_fill_manual(values = c("TRUE" = "red", "FALSE" = "blue"), 
                    labels = c("Below Average", "Above Average"),
                    name = "") +
  facet_wrap(~ paste("Cluster", CL), ncol = 7) +
  ylim(-2.5, 2.5) +  # Reduce from default range
  labs(title = "SDOH 2013 Cluster Profiles",
       x = "Indicator", 
       y = "Standardized Z-Score") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 6),
        plot.title = element_text(hjust = 0.5, size = 11, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5, size = 12),
        legend.position = "bottom",
        strip.text = element_text(size = 10, face = "bold"))

#Rotated 
# Faceted version with flipped axes
ggplot(cluster_means13, aes(x = mean_zscore, y = indicator, fill = mean_zscore > 0)) +
  geom_col(width = 0.7) +
  geom_vline(xintercept = 0, color = "black", size = 0.8) +
  scale_fill_manual(values = c("TRUE" = "red", "FALSE" = "blue"), 
                    labels = c("Below Average", "Above Average"),
                    name = "") +
  facet_wrap(~ paste("Cluster", CL), ncol = 7) +
  xlim(-2.5, 2.5) +  # Now limiting x-axis instead of y-axis
  labs(title = "SDOH 2013 Cluster Profiles",
       y = "Indicator", 
       x = "Standardized Z-Score") +
  theme_minimal() +
  theme(axis.text.y = element_text(size = 8),  # y-axis text instead of x-axis
        plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5, size = 12),
        legend.position = "bottom",
        strip.text = element_text(size = 10, face = "bold"))



#---
#show z-scores
#-----

all_zscores13 <- cluster_means13 %>%
  pivot_wider(names_from = indicator, values_from = mean_zscore) %>%
  arrange(CL)
all_zscores13

View(all_zscores13)


##check specific indicators: 
cluster_means13 %>% 
  filter(indicator == "LIMENG") %>%
  arrange(CL)


#----



#2018

# Generate boxplots for each demographic variable
for (var in demographic_vars) {
  p2018 <- ggplot(sdoh_2018, aes(x = as.factor(CL), y = .data[[var]], fill = as.factor(CL))) +
    geom_boxplot(outlier.shape = NA, alpha = 0.7) +  # Adjust alpha for visibility
    labs(title = var, x = "2018Cluster", y = var) +
    theme_minimal() +
    theme(legend.position = "none")  # Hide legends for cleaner display
  plot_list2018[[var]] <- p2018
}


grid.arrange(grobs = plot_list2018, ncol = 3, nrow = 5)

#Heatmaps for clusters

# Calculate standardized means by cluster
cluster_means18 <- sdoh_2018 %>%
  group_by(CL) %>%
  summarise(across(all_of(demographic_vars), mean, na.rm = TRUE), .groups = 'drop') %>%
  mutate(across(all_of(demographic_vars), ~ as.numeric(scale(.x)))) %>%  # Standardize AFTER grouping
  pivot_longer(cols = all_of(demographic_vars), 
               names_to = "indicator", 
               values_to = "mean_zscore")


# Check the data structure
print(head(cluster_means18))
print(colnames(cluster_means18))

# Create heatmap
ggplot(cluster_means18, aes(x = indicator, y = as.factor(CL), fill = mean_zscore)) +
  geom_tile(color = "white") +
  scale_fill_gradient2(low = "blue", mid = "white", high = "red", 
                       midpoint = 0, name = "Z-score") +
  labs(title = "Cluster Heatmap 2018",
       subtitle = "Red = Above Average, Blue = Below Average",
       x = "Indicator", y = "Cluster") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


#---
#show z-scores
#-----

all_zscores18 <- cluster_means18 %>%
  pivot_wider(names_from = indicator, values_from = mean_zscore) %>%
  arrange(CL)
all_zscores18

View(all_zscores18)


##check specific indicators: 
cluster_means18 %>% 
  filter(indicator == "LIMENG") %>%
  arrange(CL)


#----

# Faceted version for clearer individual cluster profiles
ggplot(cluster_means18, aes(x = indicator, y = mean_zscore, fill = mean_zscore > 0)) +
  geom_col(width = 0.7) +
  geom_hline(yintercept = 0, color = "black", size = 0.8) +
  scale_fill_manual(values = c("TRUE" = "red", "FALSE" = "blue"), 
                    labels = c("Below Average", "Above Average"),
                    name = "") +
  facet_wrap(~ paste("Cluster", CL), ncol = 7) +
  ylim(-2.5, 2.5) +  # Reduce from default range
  labs(title = "SDOH 2018 Cluster Profiles",
       x = "Indicator", 
       y = "Standardized Z-Score") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 6),
        plot.title = element_text(hjust = 0.5, size = 11, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5, size = 12),
        legend.position = "bottom",
        strip.text = element_text(size = 10, face = "bold"))

#Rotated 
# Faceted version with flipped axes
ggplot(cluster_means18, aes(x = mean_zscore, y = indicator, fill = mean_zscore > 0)) +
  geom_col(width = 0.7) +
  geom_vline(xintercept = 0, color = "black", size = 0.8) +
  scale_fill_manual(values = c("TRUE" = "red", "FALSE" = "blue"), 
                    labels = c("Below Average", "Above Average"),
                    name = "") +
  facet_wrap(~ paste("Cluster", CL), ncol = 7) +
  xlim(-2.5, 2.5) +  # Now limiting x-axis instead of y-axis
  labs(title = "SDOH 2018 Cluster Profiles",
       y = "Indicator", 
       x = "Standardized Z-Score") +
  theme_minimal() +
  theme(axis.text.y = element_text(size = 8),  # y-axis text instead of x-axis
        plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5, size = 12),
        legend.position = "bottom",
        strip.text = element_text(size = 10, face = "bold"))

#2023
# Generate boxplots for each demographic variable
for (var in demographic_vars) {
  p2023 <- ggplot(sdoh_2023, aes(x = as.factor(CL), y = .data[[var]], fill = as.factor(CL))) +
    geom_boxplot(outlier.shape = NA, alpha = 0.7) +  # Adjust alpha for visibility
    labs(title = var, x = "2023Cluster", y = var) +
    theme_minimal() +
    theme(legend.position = "none")  # Hide legends for cleaner display
  plot_list2023[[var]] <- p2023
}

grid.arrange(grobs = plot_list2023, ncol = 3, nrow = 5)

#Heatmaps for clusters

# Calculate standardized means by cluster
cluster_means23 <- sdoh_2023 %>%
  group_by(CL) %>%
  summarise(across(all_of(demographic_vars), mean, na.rm = TRUE), .groups = 'drop') %>%
  mutate(across(all_of(demographic_vars), ~ as.numeric(scale(.x)))) %>%  # Standardize AFTER grouping
  pivot_longer(cols = all_of(demographic_vars), 
               names_to = "indicator", 
               values_to = "mean_zscore")


# Check the data structure
print(head(cluster_means23))
print(colnames(cluster_means23))

# Create heatmap
ggplot(cluster_means23, aes(x = indicator, y = as.factor(CL), fill = mean_zscore)) +
  geom_tile(color = "white") +
  scale_fill_gradient2(low = "blue", mid = "white", high = "red", 
                       midpoint = 0, name = "Z-score") +
  labs(title = "Cluster Heatmap 2023",
       subtitle = "Red = Above Average, Blue = Below Average",
       x = "Indicator", y = "Cluster") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

#---
#show z-scores
#-----

all_zscores23 <- cluster_means23 %>%
  pivot_wider(names_from = indicator, values_from = mean_zscore) %>%
  arrange(CL)
all_zscores23

View(all_zscores23)


##check specific indicators: 
cluster_means23 %>% 
  filter(indicator == "LIMENG") %>%
  arrange(CL)


#----
#---

# Faceted version for clearer individual cluster profiles
ggplot(cluster_means23, aes(x = indicator, y = mean_zscore, fill = mean_zscore > 0)) +
  geom_col(width = 0.7) +
  geom_hline(yintercept = 0, color = "black", size = 0.8) +
  scale_fill_manual(values = c("TRUE" = "red", "FALSE" = "blue"), 
                    labels = c("Below Average", "Above Average"),
                    name = "") +
  facet_wrap(~ paste("Cluster", CL), ncol = 7) +
  ylim(-2.5, 2.5) +  # Reduce from default range
  labs(title = "SDOH 2013 Cluster Profiles",
       x = "Indicator", 
       y = "Standardized Z-Score") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 6),
        plot.title = element_text(hjust = 0.5, size = 11, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5, size = 12),
        legend.position = "bottom",
        strip.text = element_text(size = 10, face = "bold"))

#Rotated 
# Faceted version with flipped axes
ggplot(cluster_means23, aes(x = mean_zscore, y = indicator, fill = mean_zscore > 0)) +
  geom_col(width = 0.7) +
  geom_vline(xintercept = 0, color = "black", size = 0.8) +
  scale_fill_manual(values = c("TRUE" = "red", "FALSE" = "blue"), 
                    labels = c("Below Average", "Above Average"),
                    name = "") +
  facet_wrap(~ paste("Cluster", CL), ncol = 7) +
  xlim(-2.5, 2.5) +  # Now limiting x-axis instead of y-axis
  labs(title = "SDOH 2023 Cluster Profiles",
       y = "Indicator", 
       x = "Standardized Z-Score") +
  theme_minimal() +
  theme(axis.text.y = element_text(size = 8),  # y-axis text instead of x-axis
        plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5, size = 12),
        legend.position = "bottom",
        strip.text = element_text(size = 10, face = "bold"))

#2023 v2 JULY 2025
# Generate boxplots for each demographic variable
for (var in demographic_vars) {
  p2023 <- ggplot(sdoh_2023_july2025, aes(x = as.factor(CL), y = .data[[var]], fill = as.factor(CL))) +
    geom_boxplot(outlier.shape = NA, alpha = 0.7) +  # Adjust alpha for visibility
    labs(title = var, x = "2023Cluster", y = var) +
    theme_minimal() +
    theme(legend.position = "none")  # Hide legends for cleaner display
  plot_list2023[[var]] <- p2023
}

grid.arrange(grobs = plot_list2023v2, ncol = 3, nrow = 5)

#Heatmaps for clusters

# Calculate standardized means by cluster
cluster_means23 <- sdoh_2023_july2025 %>%
  group_by(CL) %>%
  summarise(across(all_of(demographic_vars), mean, na.rm = TRUE), .groups = 'drop') %>%
  mutate(across(all_of(demographic_vars), ~ as.numeric(scale(.x)))) %>%  # Standardize AFTER grouping
  pivot_longer(cols = all_of(demographic_vars), 
               names_to = "indicator", 
               values_to = "mean_zscore")


# Check the data structure
print(head(cluster_means23))
print(colnames(cluster_means23))

# Create heatmap
ggplot(cluster_means23, aes(x = indicator, y = as.factor(CL), fill = mean_zscore)) +
  geom_tile(color = "white") +
  scale_fill_gradient2(low = "blue", mid = "white", high = "red", 
                       midpoint = 0, name = "Z-score") +
  labs(title = "Cluster Heatmap 2023",
       subtitle = "Red = Above Average, Blue = Below Average",
       x = "Indicator", y = "Cluster") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

#---
#show z-scores
#-----

all_zscores23 <- cluster_means23 %>%
  pivot_wider(names_from = indicator, values_from = mean_zscore) %>%
  arrange(CL)
all_zscores23

View(all_zscores23)


##check specific indicators: 
cluster_means23 %>% 
  filter(indicator == "LIMENG") %>%
  arrange(CL)


#----
#---

# Faceted version for clearer individual cluster profiles
ggplot(cluster_means23, aes(x = indicator, y = mean_zscore, fill = mean_zscore > 0)) +
  geom_col(width = 0.7) +
  geom_hline(yintercept = 0, color = "black", size = 0.8) +
  scale_fill_manual(values = c("TRUE" = "red", "FALSE" = "blue"), 
                    labels = c("Below Average", "Above Average"),
                    name = "") +
  facet_wrap(~ paste("Cluster", CL), ncol = 7) +
  ylim(-2.5, 2.5) +  # Reduce from default range
  labs(title = "SDOH 2013 Cluster Profiles",
       x = "Indicator", 
       y = "Standardized Z-Score") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 6),
        plot.title = element_text(hjust = 0.5, size = 11, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5, size = 12),
        legend.position = "bottom",
        strip.text = element_text(size = 10, face = "bold"))

#Rotated 
# Faceted version with flipped axes
ggplot(cluster_means23, aes(x = mean_zscore, y = indicator, fill = mean_zscore > 0)) +
  geom_col(width = 0.7) +
  geom_vline(xintercept = 0, color = "black", size = 0.8) +
  scale_fill_manual(values = c("TRUE" = "red", "FALSE" = "blue"), 
                    labels = c("Below Average", "Above Average"),
                    name = "") +
  facet_wrap(~ paste("Cluster", CL), ncol = 7) +
  xlim(-2.5, 2.5) +  # Now limiting x-axis instead of y-axis
  labs(title = "SDOH 2023 Cluster Profiles JULY 2025",
       y = "Indicator", 
       x = "Standardized Z-Score") +
  theme_minimal() +
  theme(axis.text.y = element_text(size = 8),  # y-axis text instead of x-axis
        plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5, size = 12),
        legend.position = "bottom",
        strip.text = element_text(size = 10, face = "bold"))


#COMPARE ACROSS YEARS

# Combine all three datasets with year labels
combined_data <- bind_rows(
  cluster_means %>% mutate(year = "2013"),
  cluster_means18 %>% mutate(year = "2018"),
  cluster_means23 %>% mutate(year = "2023")
) %>%
  mutate(
    cluster_year = paste("Cluster", CL, year),
    year = factor(year, levels = c("2013", "2018", "2023"))
  )

# Create the combined plot
ggplot(combined_data, aes(x = mean_zscore, y = indicator, fill = mean_zscore > 0)) +
  geom_col(width = 0.7) +
  geom_vline(xintercept = 0, color = "black", size = 0.8) +
  scale_fill_manual(values = c("TRUE" = "red", "FALSE" = "blue"), 
                    labels = c("Below Average", "Above Average"),
                    name = "") +
  facet_grid(CL ~ year, 
             labeller = labeller(CL = function(x) paste("Cluster", x),
                                 year = function(x) x)) +
  xlim(-2.5, 2.5) +
  labs(title = "SDOH Cluster Profiles: 2013, 2018, and 2023",
       y = "Indicator", 
       x = "Standardized Z-Score") +
  theme_minimal() +
  theme(axis.text.y = element_text(size = 4),
        axis.text.x = element_text(size = 4),
        plot.title = element_text(hjust = 0.5, size = 10, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5, size = 12),
        legend.position = "bottom",
        strip.text = element_text(size = 6, face = "bold"),
        panel.spacing = unit(0.5, "lines"))


# Export z-scores
write.csv(all_zscores13, "zscores2013.csv", row.names = FALSE)
write.csv(all_zscores18, "zscores2018.csv", row.names = FALSE)
write.csv(all_zscores23, "zscores2023.csv", row.names = FALSE)
